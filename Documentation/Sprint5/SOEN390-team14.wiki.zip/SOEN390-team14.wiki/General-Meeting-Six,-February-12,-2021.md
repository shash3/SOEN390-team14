***

**Present members:**
* All members were present during this meeting  

***

**Meeting start time:**
* 1:00 pm EST  

**Meeting duration:**  
* 60 minutes

***

**Topics discussed:**
* Organized when to meet with TA  
* Discussed fixing problems with Sprint 1 for end of Sprint 2  
* Everyone should improve their documentation  
* Sacha made programming lead  
* Need to update ReadMe  
* User permissions  
* Need project outline to understand how pages interact with one another. This will be done in a block diagram  
* Have a working navbar -- discussed how ERP will work  
* encryption of data  
* Creation of materials list  
* Business Account page  
* Fixed Sprint 2 scheduling  

***
**Next meeting:**  
* Meeting with TA: February 15, 2021, at 4pm EST  

***

