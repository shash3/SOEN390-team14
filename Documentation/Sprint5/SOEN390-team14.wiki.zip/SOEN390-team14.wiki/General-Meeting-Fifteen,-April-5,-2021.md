***

**Present members:**  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   
* Ashraf Khalil  

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 75 minutes

***

**Topics discussed:**
* spoke about the export to pdf function.  
* We were unclear as to what features should be exported into a pdf and what feature so we decided to ask the TA.  
* spoke about Sacha's PR. added a bug and marked it as fix.  
* Everyone is on schedule and we are looking good to finish on time.  
* Derek demoed the features he added (export to excel and graphs for planning)  
* Accountability Log still needs to be done.  
* went throught the application and marked everything that still has to be done.  
* decided to meet tomorrow  

***
**Next meeting:**  
* General Meeting: April 7, 2021 time TBD  

***
