***

**Present members:**
* Adam Richard  
* Shashank Patel  
* Derek Ruiz-Cigana  
* Sacha Elkaim  
* Ashraf Khalil

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 40 minutes

***

**Topics discussed:**
* Tasks for Sprint 3 + scheduling  
* Went through tasks and user stories  
* Plans for tackling this Sprint (many story points, little time)  
* Selenium for UI testing  
* Finance and Quality to be looked at next week  
* Defects tracking as continual process -> report bugs as you come across them, remove from report as they are fixed  
* Schedule meeting with TA once grades are released   

***
**Next meeting:**  
* General Meeting: March 8, 2021, time TBD  

***

