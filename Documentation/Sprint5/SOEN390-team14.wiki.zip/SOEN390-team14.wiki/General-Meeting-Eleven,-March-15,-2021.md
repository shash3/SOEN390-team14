***

**Present members:**
* All members were present during this meeting    

***

**Meeting start time:**
* 3:20 pm EST  

**Meeting duration:**  
* 120 minutes

***

**Topics discussed:**
* Changes to documentation  
* Changes to Docker command  
* Needed changes to accounts receivable and payable, plus shipments  
* Front-End mostly done  
* Sales and Procurement still needs to talk to transportation, plus other connections  
* discussed functionality of ESLint  
* issue with help page icons for UI testing --> new page or new window?  
* functionality of FAQ  
* tag issues for commits  
* went through Release Plan  
* discussed password input for Registration  

***
**Next meeting:**  
* General Meeting: March 17, 2021, Time TBD  

***

