***

**Present members:**
* Adam Richard  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   
* Ashraf Khalil  

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 60 minutes

***

**Topics discussed:**
* Where to host application  
* Sprint 4 Release Plan --> Distribution of tasks  
* Functionality of Production Machinery Communication  
* Production Assembly Line already done  
* Quality of source code reviews -- manual?  
* Meet with TA once we have feedback  

***
**Next meeting:**  
* Meeting with TA: March 29, 2021, 3:00 pm EST  
* Followed immediately by general meeting    

***

