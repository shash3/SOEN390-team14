***

**Present members:**
* All members were present at this meeting 

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 25 minutes

***

**Topics discussed:**
* Grade for Release Plan is Release Plan + SAD  
* Source Code --> can input invalid data freely  
* Code conventions are not being followed  
* Use GitHub pages to create a static page to show a report, easier to review project  
* Check out Figma for UI Prototypes  

***

Next Meeting: General Meeting, March 29, 2021, immediately following

***