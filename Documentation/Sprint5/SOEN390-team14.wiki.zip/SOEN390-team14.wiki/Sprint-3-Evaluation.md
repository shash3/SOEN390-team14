# 1. What you did well (in addition to the last sprint)

## 1.1. General

* OK release plan
* OK risk tracking list and Risk management. If you're using an online document for this list, you should include the link to the online (live) document.
* OK UI prototype. Did you think of using collaboration services like [Figma](https://www.figma.com/pricing/)?
* Usage of a unified format among documents.

## 1.2. Software Architecture Description

* Improved format.
* Correctly describe MVC design pattern.

## 1.3. Source code

* Have code analysis and CI

# 2. What you need to improve

## 2.1. Features, requirements and User stories

* I can barely see the hierarchy structure of the features > requirements > user stories

## 2.2. Software Architecture Description

* **_Table of contents doesn’t have bookmarks. Cannot quickly navigate between parts (Risk management plan, SAD, UI Prototype)_**

Example:
![toc](https://i.imgur.com/FQChD11.png)

* Figure 11: There is no connection between the `_Auth` classes?
* Figure 11: The relationship between models are not correct
* Development View: Still not a clear explanation of the diagram.
    * What is `Client Workstation PC`?
    * What is `Application Host`?
    * Why there are 2 Front-end servers and 2 Back-end servers?

> As I understand, you packed your application in Docker images. User can pull and deploy these images into docker containers? If this is correct, this information is nothing to do with deployment diagrams.

## 2.3. Release plan

* Error logging: Just show a notification, not a real logging system.

## 2.4. Defect tracking report

* This list is not defects but code smells. Defects are something like known bugs that should be fixed but weren't.

## 2.5. Source code

* I can freely input invalid data

![invalid data](https://i.imgur.com/8aTS4k3.png)

* ESLint for client, but not for server?
* Inconsistent format

![inconsistent](https://i.imgur.com/dOFZXkK.png)

* code analysis should exclude 3rd party libs
* too much linting error - low code quality

## 2.6. Source code checklist

- [x] Quality of source code reviews - Too many linting errors, low maintainability
- [x] correct use of design patterns - Only 1 design pattern used: MVC
- [ ] respect to code conventions - Coding convention was not respected
- [ ] design quality as measured by the number of classes/packages, module size, coupling, cohesion - None
- [x] quality of source code documentation - ok
- [x] refactoring activity documented in commit messages - ok
- [x] quality/detail of commit messages - some commit messages are still too general
- [x] use of feature branches - ok
- [x] atomic commits - ok
- [ ] linking of commits to bug reports/ features - None

# 3. Marks

| Content | Max | Earned |
|-|-|-|
| Sprint 3 deliverables:<br>New Deliverables:<br>1. Defects tracking report<br>2. Release Plan (Sprint #3 planning)<br>3. UI modeling of Sprint #3 user stories<br>Updated deliverables: SAD, USB, RMP, Testing Plan | 20 | 18 |
| - Updated/Changed User Stories + Risks | 2 | 2 |
| - Updated Software Architecture: Class diagram | 2 | 2 |
| - Release Plan for Sprint #4 | 2 | 1 |
| - Testing Report: unit tests for the implemented code | 2 | 2 |
| - Updates on the UI Prototypes based on project owner feedback + New UI prototypes | 3 | 3 |
| - Software Implementation of planned user stories + Bug reports/fixing:<br>  + Quality of source code reviews<br>  + correct use of design patterns<br>  + respect to code conventions<br>  + design quality as measured by number of classes/packages, module size, coupling, cohesion<br>  + quality of source code documentation<br>  + refactoring activity documented in commit messages<br>  + quality/detail of commit messages<br>  + use of feature branches<br>  + atomic commits<br>  + linking of commits to bug reports/features | 5 | 4 |
| - Presentation/Demo to the Product Owner | 4 | 4 |