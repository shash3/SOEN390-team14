***

**Present members:**
* Adam Richard  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   
* Ashraf Khalil  

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 60 minutes

***

**Topics discussed:**
* Self-evaluation  
* Post-mortem --> brainstormed main parts  

***
**Next meeting:**  
* General Meeting: Monday, April 19, 2021    

***
