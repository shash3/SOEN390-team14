### Wiki for Sprint 5
All Links and information relevant to Sprint 5 are present below, sorted by category, as well as information for upcoming meetings.
***
## Meetings
### General Meetings:  
[Meeting One: April 4, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Seventeen,-April-4,-2021)  
[Meeting Two: April 19, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Eighteen,-April-19,-2021)  
***
## Sprint Evaluations:  
***