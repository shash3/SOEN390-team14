
***
**Present members:**
* Adam Richard
* Shashank Patel
* Sacha Elkaim
* Derek Ruiz-Cigana
* Michael Takena
* Ashraf Khalil
* James El-Tayar

***
**Meeting start time:**  
* 2:40 pm EST  

**Meeting duration:**  
* 50 minutes

***
**Topics Discussed:**
* Ability to get GitHub, React (front-end), and NodeJS (back-end) working on our individual computers
* Shashank and Sacha will be available to troubleshoot should any weird issue arise
* Decided to use MongoDB (MERN) for database instead of firebase. This should be reflected in the ReadMe
* Prepared subjects of discussion for meeting with TA
     > What do we need for the prototype?  
     > What are the clients needs? What kind of Bike Shop is it?
     > General context questions  
     > Where do we upload documentation/where do we submit?  
     > What is expected at the demo?  
* Discussed the login system for employees vs customers. A single login system will be used for the prototype
* Testing technology. Travis CI will be used for integrated testing with GitHub, and JEST will be used for unit testing with React
* Chose color scheme of the web app. Black, grey, and blue will be used
* Created Sprint 1 Milestone in GitHub and began adding documentation issues
* Finalized plans for finishing sprint, all members understand their roles

***
**Next meeting:**  
* Wednesday, February 3, 2021 at 6:30 pm EST

***
