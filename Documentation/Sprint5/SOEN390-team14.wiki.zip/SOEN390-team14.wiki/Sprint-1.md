### Wiki for Sprint 1
All Links and information relevant to Sprint 1 are present below, sorted by category, as well as information for upcoming meetings.
***
## Meetings
### General Meetings:
[Meeting One : January 18, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-One,-January-18,-2021)  
[Meeting Two : January 25, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Two,-January-25,-2021)  
[Meeting Three : February 1, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Three,-February-1,-2021)  
[Meeting Four : February 3, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Four,-February-3,-2021) 
### Programming Meetings:
[Meeting One : January 28, 2021](https://github.com/shash3/SOEN390-team14/wiki/Programming-Meeting-One,-January-28,-2021) 

***
## Sprint Evaluations:  
[Sprint One Evaluation](https://github.com/shash3/SOEN390-team14/wiki/Sprint-1-Evaluation)  