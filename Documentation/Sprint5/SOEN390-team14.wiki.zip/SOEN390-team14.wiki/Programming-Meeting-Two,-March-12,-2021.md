
***
**Present members:**
* Sacha Elkaim
* Shashank Patel
* Derek Ruiz-Cigana
* Ashraf Khalil
* James El Tayar  

***
**Meeting start time:**
* 5:00 pm EST

**Meeting duration:**
* 60 minutes

***
**Topics discussed:**
* Connections between transportation and production  
* Re-divided programming tasks  

***
**Next meeting:**
* Meeting with TA, Monday, March 15, 2021, 3pm EST  

***
