***

**Present members:**
* Adam Richard  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   

***

**Meeting start time:**
* 5:30 pm EST  

**Meeting duration:**  
* 150 minutes

***

**Topics discussed:**
* Finalized Deliverables for Sprint 3  

***
**Next meeting:**  
* General Meeting: March 22, 2021, Time TBD  

***

