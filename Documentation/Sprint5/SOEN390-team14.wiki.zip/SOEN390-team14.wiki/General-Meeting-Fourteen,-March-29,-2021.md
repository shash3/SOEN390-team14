***

**Present members:**
* Adam Richard  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   
* Ashraf Khalil  

***

**Meeting start time:**
* 3:25 pm EST  

**Meeting duration:**  
* 60 minutes

***

**Topics discussed:**
* Where to improve in Sprint 4  
* Fix SAD  
* update UI Prototypes  
* ESLint complains about console logs  
* get rid of alerts, keep logs  
* Export to PDF functionality  
* Tooltips  

***
**Next meeting:**  
* Programming Meeting: April 1, 2021 at 3pm EST  

***
