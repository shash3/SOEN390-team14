
***
**Present members:**
* Sacha Elkaim
* Shashank Patel
* Derek Ruiz-Cigana
* Ashraf Khalil
* Michael Takenaka  
* Adam Richard

***
**Meeting start time:**
* 3:45 pm EST

**Meeting duration:**
* 45 minutes

***
**Topics discussed:**
* UI testing - front end methods  
* Adam had issue with GitHub local repo  
* when interacting with variable names, mind your casing  
* got Prettier to work --> details in discord  
* Ashraf and James going to grind a lot  
* update on how everyone is doing  
* production tab functionality  
--> needs to be broken down into (example) type of bike  
--> Planning --> how many to make? How many already made? which plant?  

***
**Next meeting:**
* General Meeting, Monday, April 5, 2021, 3pm EST  

***
