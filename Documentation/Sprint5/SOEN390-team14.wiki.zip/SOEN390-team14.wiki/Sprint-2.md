### Wiki for Sprint 2
All Links and information relevant to Sprint 2 are present below, sorted by category, as well as information for upcoming meetings.
***
## Meetings
### General Meetings:
[Meeting One: February 8, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Five,-February-8,-2021)  
[Meeting Two: February 12, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Six,-February-12,-2021)  
[Meeting Three: February 15, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Seven,-February-15,-2021)  
[Meeting Four: February 22, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Eight,-February-22,-2021)

### Meetings with TA:  
[Meeting One : February 15, 2021](https://github.com/shash3/SOEN390-team14/wiki/Meeting-with-TA-One,-February-15,-2021)  

***
## Sprint Evaluations:  
[Sprint Two Evaluation](https://github.com/shash3/SOEN390-team14/wiki/Sprint-2-Evaluation)  