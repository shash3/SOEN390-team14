***

**Present members:**
* All members were present during this meeting  

***

**Meeting start time:**
* 4:30 pm EST  

**Meeting duration:**  
* 70 minutes

***

**Topics discussed:**
* Met to discuss answers to questions for TA and next steps  
* Organization of ERP  
* Functionality of system  
* Re-divided tasks for Sprint 2, this took some time  
* This discussion included further specification of functionality of app  
* Manufacturing process  
* Sacha and Adam available to help with anything if someone needs  

***
**Next meeting:**  
* General Meeting: February 22, 2021, time TBD  

***

