***

**Present members:**
* Adam Richard
* Sacha Elkaim
* Shashank Patel
* Derek Ruiz-Cigana
* Michael Takena
* James El-Tayar

***

**Meeting start time:**
* 6:30 pm EST  

**Meeting duration:**  
* 60 minutes

***

**Topics discussed:**
* Running docker - managing front and back end on docker
* State of documentation
* What is needed to finish the sprint
* GitHub user stories - organized by Milestone
* Release plan for future sprints - completed tentative release plan
* Planned for Sprint 2
* Discussed UI Prototype - what prototyping is needed for Sprint 2
* Completed UI Prototyping
* Finalized necessary components of sprint 1
* Q's for TA, what belongs on portal?
* Where exactly on supply chain are we?

***
**Next meeting:**  
* February 4, 2021 at 2:30 pm EST -- DEMO

***

