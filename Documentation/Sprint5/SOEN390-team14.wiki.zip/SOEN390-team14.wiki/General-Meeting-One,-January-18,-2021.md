
***

**Present members:**
* All members were present during this meeting.

***

**Meeting start time:**
* 4:00 pm EST  

**Meeting duration:**  
* 45 minutes

***

**Topics discussed:**
* Reorganization of the already-created Discord server, which will serve as the virtual location where the team will host meetings, discussions, and work.
* Chose technology to be used for the project:  
     > Front-end: React  
     > Back-end: NodeJS  
     > Database: Firebase or SQL  
* Created GitHub repository for project, where work will be uploaded and tracked.
* Created Google Drive, where documentation can be accessed and worked on.
* Discussed general project requirements to ensure all members were up to speed.

***
