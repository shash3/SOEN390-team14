
***
**Present members:**
* Adam Richard
* Shashank Patel
* Sacha Elkaim
* Derek Ruiz-Cigana
* Michael Takena
* Jamil Hirsh
* Ashraf Khalil

***

**Meeting start time:**  
* 3:20 pm EST  

**Meeting duration:**  
* 50 minutes

***
**Topics discussed:**  
* Requirements for Sprint 1
* Understanding the goals of the sprint and review of the given templates
* Possible sprint rotations for programming and documentation
* Decided that two people's approval would be needed in order to merge onto Master
* Meetings will be held minimally once a week, _but should be twice a week_
* User stories should be added to the Issues page on the GitHub repository
* Discussed requirements for Prototype needed for first sprint
     -> Will set up the Front-End, Back-End, and Database
* Tasks assigned for Sprint 1 according to the following:
     > Ashraf & James: Risk Assessment & Risk Management Plan  
     > Michael & Derek: User Story Backlog  
     > Adam & Jamil: Software Architecture Document  
     > Sacha & Shashank: Set up the running prototype, join whichever sub-team needs help  
* Sprint 2 planning, UI Prototypes, Testing Plan will be discussed and implemented after next meeting (Thursday, Jan. 28)
* Release Plan to be discussed at next meeting (Thursday, Jan. 28)

***
**Next meeting:**  
* Thursday, January 28, 2021 at 3:30 pm EST

***
