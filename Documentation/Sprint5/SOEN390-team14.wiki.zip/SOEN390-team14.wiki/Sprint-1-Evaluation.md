# 1. What you did well
* Have meeting minutes
* Github well used (Issues, mentions, wiki, etc)
* Have CI (travis, you can use Github built-in actions)
* Distributed tasks well (on the source code)
* Good presentation

# 2. What you need to improve

## 2.1. General
* Misunderstood User story and Backlog
* No list of chosen requirements (I can understand it as a consequence of the misunderstanding user story and backlog)
* _**No project management (don’t mention it anywhere)**_
* Inconsistency in version naming of the documents
* _**Not fulfill all user stories**_
* _**Unnecessary user stories. No need to include user stories of dev stakeholders**_

## 2.2. SAD
* Table of contents is not clickable (doesn’t have bookmarks). Cannot quickly navigate between parts
* _**Introduction doesn’t introduce the system, or the need of the system.**_
* Should have a graph for stakeholders
* _**Doesn’t state the model to use in View and Viewpoints**_
* _**No deployment view**_
* _**Misunderstood the Viewpoint definition**_
* Doesn’t need to state UML notation on each part. Simply put it in once somewhere.
* _**Wrong notation for figure 2, 3, 4 (the arrows)**_
* Doesn’t explain why the arrow is only 1 way in Implementation view

## 2.3. UI Prototype
* Use the wrong name for the document
* _**Prototype doesn’t have description or naming**_
* Missing multiple prototype (expected one for each User story or related user stories)
* Dummy text in the prototype. If the function is not available, do not include it

## 2.4. Risk management Plan
* Expired link in the document
* Dummy data on risk tracking

## 2.5. Testing plan
* Table of contents doesn’t have bookmarks. Cannot quickly navigate between parts
* _**No integration test, no manual test**_

## 2.6. Source code
* _**Not conform MVC design pattern (should explain why you name the folder “routes/api”, why split auth and register to 2 different files)**_
* _**No coding convention**_
* Merge branch is not deleted
* Travis status is not included in Readme
* _**Incomplete readme**_
* No database schema in source code
* _**No prerequisite for continuing development (do I need to install MongoDB?)**_

# 3. Marks

| Sprints | Contents | Max marks | Earned |
|-|-|-|-|
| Sprint 1<br>Jan.13 – Feb. 3 | Deliverables:<br>1. User Stories Backlog (USB)<br>2. Release Plan (Sprint #2 planning)<br>3. Software Architecture Document (SAD)<br>4. Risk Assessment & Risk Management Plan (RMP)<br>5. UI prototypes for Sprint #2 user stories<br>6. Testing Plan<br>7. Running software | 20 | 14 |
|  | - User Stories Backlog: completeness, meaningfulness, respect to format/conventions | 3 | 3 |
|  | - Software Architecture: completeness of Domain Model, Component diagram | 3 | 1 |
|  | - Release Plan for Sprint #2: breakdown to sub-user stories, over/under-estimation of the number and difficulty (USP) of user stories, acceptance tests passed at the end of the next sprint | 2 | 2 |
|  | - Risk Assessment and Management Plan | 2 | 1 |
|  | - UI Prototypes: variety of prototypes, complexity of the UI, user story coverage | 4 | 2 |
|  | - Testing Plan: research on testing frameworks, evidence of successful installation/execution of testing frameworks | 2 | 2 |
|  | - Live presentation/Demo to the Product Owner: punctuality, communication skills, addressing comments/questions<br>(Will be ask to provide explanations about the code) + Docker with the running code | 4 | 3 |