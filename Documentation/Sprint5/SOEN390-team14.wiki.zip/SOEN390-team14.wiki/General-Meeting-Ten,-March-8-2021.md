***

**Present members:**
* Adam Richard  
* Shashank Patel  
* Derek Ruiz-Cigana  
* Sacha Elkaim  
* Ashraf Khalil
* Jamil Hirsh  
* Michael Takenaka  

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 120 minutes

***

**Topics discussed:**
* Materials in database all that's left for production tab  
* Shashank got unit tests to work + discussed how unit tests work  
* Production finished, so QA started  
* Discussed inventory -> raw materials should be separate from items? inventory vs finished product?  
* QA as attribute? Filter by attribute  
* Parts do not appear in inventory until QA is done  
* Technically have head-start on QA tab  
* Transportation will be done by Wednesday  
* Documentation cannot be started yet  
* Make shipment checks if you have product -> 2 lists in transportation? Incoming, Outgoing  
* Used UI prototypes to help discuss new aspects of app  
* Accounting should update budget  
* Error logging -> one for debugging + one for accountability (defects tracking)  
* Actual error logging -> every button pushed should save to log  
* Login encryption  
* UI testing should start ASAP so that we can get help with Finance tab  
* Procurement is page where things are bought  
* Price of products  

***
**Next meeting:**  
* Programming Meeting: March 12, 2021, 5pm EST  

***

