***

**Present members:**  
* Derek Ruiz-Cigana  
* James El-Tayar  
* Michael Takenaka  
* Sacha Elkaim  
* Shashank Patel   
* Ashraf Khalil  
* Adam Richard  

***

**Meeting start time:**
* 8:00 pm EST  

**Meeting duration:**  
* 120 minutes

***

**Topics discussed:**
* Finalized Sprint 4 details  

***
**Next meeting:**  
* TBD  

***
