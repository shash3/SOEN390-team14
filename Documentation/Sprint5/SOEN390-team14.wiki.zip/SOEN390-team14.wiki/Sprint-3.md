### Wiki for Sprint 3
All Links and information relevant to Sprint 3 are present below, sorted by category, as well as information for upcoming meetings.
***
## Meetings
### General Meetings:
[Meeting One: March 2, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Nine,-March-2,-2021)  
[Meeting Two: March 8, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Ten,-March-8-2021)  
[Meeting Three: March 15, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Eleven,-March-15,-2021)  
[Meeting Four: March 17, 2021](https://github.com/shash3/SOEN390-team14/wiki/General-Meeting-Twelve,-March-17,-2021)  
### Programming Meetings:  
[Programming Meeting One: March 12, 2021](https://github.com/shash3/SOEN390-team14/wiki/Programming-Meeting-Two,-March-12,-2021)  
### TA Meetings:  
[Meeting with TA One: March 15, 2021](https://github.com/shash3/SOEN390-team14/wiki/Meeting-with-TA-Two,-March-15,-2021)  
***
## Sprint Evaluations:  
[Sprint 3 evaluation](https://github.com/shash3/SOEN390-team14/wiki/Sprint-3-Evaluation)
***