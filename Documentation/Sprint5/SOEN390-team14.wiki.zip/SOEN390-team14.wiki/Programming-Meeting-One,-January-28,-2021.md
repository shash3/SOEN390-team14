
***
**Present members:**
* Sacha Elkaim
* Adam Richard
* Shashank Patel
* Derek Ruiz-Cigana
* Ashraf Khalil

***
**Meeting start time:**
* 3:30 pm EST

**Meeting duration:**
* 30 minutes

***
**Topics discussed:**
* Demo on how to install necessary dependencies for project
* How to run the prototype
* Ran the prototype
* Additional needs for prototype

***
**Next meeting:**
* Monday, February 1, 2021

***
