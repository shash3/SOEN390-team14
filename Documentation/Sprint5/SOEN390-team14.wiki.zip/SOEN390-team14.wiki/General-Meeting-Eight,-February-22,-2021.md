***

**Present members:**
* Derek Ruiz-Cigana  
* Shashank Patel  
* Sacha Elkaim  
* Michael Takenaka  
* Jamil Hirsh  
* james El Tayar  

***

**Meeting start time:**
* 8:00 pm EST  

**Meeting duration:**  
* 140 minutes

***

**Topics discussed:**
* The logistics of how to organize the databases of: overall inventory, production inventory, transportation inventory, Quality Assurance inventory.  
* Thinking of pushing the transportation user stories to sprint 3 if cannot be complete in time, but planning to keep it for sprint 2 though.  
* Clarifying design of material/product management and product lifecycle. For example: a material is bought from finance department, then transportation department, handles shipment intake and outgoing, then material is added to production inventory, then production user can use material for parts.  
* Design of transportation backend (database) and front end. What the page could look like and the functionality that the database must provide.  
* Each user is assigned a location that they work at (plant 1 or Montreal) by the admin (the admin can change their location but it is assigned when their account is created). Each user of production will see the inventory of every plant, but can only interact with parts and materials from their plant.  
* A production user selects a part that they want to create from a list.  
* If they have all the required materials in inventory at their plant: -> then a confirmation will appear saying that it is good to make, and the materials will be removed from inventory.  
* Else if they do not have all the required materials in inventory at their plant:  
-> (1) then they can choose to import from another plant that has enough of that material  
-> (2) or they can choose to buy more of that material from the manufacturer.  
* If (1) then they send a request to the transportation department with the information of: item name, quantity, from where, to where, date of request. Then transportation will move the desired quantity of items from the request. After the items are transported and delivered to the new plant then the transportation department will add the items to the inventory of the new location and the production department can use the items.  
* If (2) then production department sends a request to Finance (subtab of procurement) with information of: item name, quantitym to where, date of request. Then Finance will allocate the budget and send a request to transportation with the same information as (1) but with "from where" being filled as manufacturer.  

***
**Next meeting:**  
* General meeting: March 1, 2021

***

