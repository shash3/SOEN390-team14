***

**Present members:**
* Adam Richard (late by 10 mins)
* Sacha Elkaim
* Derek Ruiz-Cigana
* Michael Takenaka
* Jamil Hirsh
* Ashraf Khalil

***

**Meeting start time:**
* 4:10 pm EST  

**Meeting duration:**  
* 20 minutes

***

**Topics discussed:**
* Derek and Michael offered to Reorganize Sprint 2
* Our expectations for the Sprint were incorrect
* We will have another meeting Thursday or Friday to discuss new organization
* Question about purchasing - directly from website or by contract?
* We will schedule a meeting with the TA to discuss the project

***
**Next meeting:**  
* General meeting: TBD
* Meeting with TA: TBD

***

