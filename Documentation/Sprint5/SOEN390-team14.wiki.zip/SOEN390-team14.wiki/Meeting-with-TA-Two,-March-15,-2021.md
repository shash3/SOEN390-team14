***

**Present members:**
* All members were present at this meeting 

***

**Meeting start time:**
* 3:00 pm EST  

**Meeting duration:**  
* 20 minutes

***

**Topics discussed:**
* lines in User Story diagrams should be separate  
* use headings to create bookmakrs  
* we did not change stack, TA confused us with another group  
* should have more detailed commit messages  
* just need to export to excel when exporting  
* save excel documents in excel format  
* how to use single command for two containers on Docker?  
--> comabine commands, or  
--> include front and back end on same image  
* should test docker on clean machine  
* Prototypes to be submitted for this Sprint are Sprint 3 prototypes, just update them  

***

Next Meeting: General Meeting, March 15, 2021, immediately following

***