# 1. What you did well (in addition to the last sprint)

## 1.1. General

* Improvements addressing the feedbacks from last sprints

# 2. What you need to improve

## 2.1. General

* LATE SUBMISSION - Although you create the release late, but the commit was on time, so I will accept this for not being late.
* Inconsistent tag names

![tag names](https://i.imgur.com/rPAzxzg.png)

## 2.2. Application

* There are some placeholder buttons that do nothing

![placeholder](https://i.imgur.com/FeLWTpc.png)

* I can freely input invalid data

![invalid](https://i.imgur.com/D92YIsn.png)

* If a feature is not ready, do not include it in the UI

![hard coded](https://i.imgur.com/cIYaeUi.png)

* Change permission not working

![permission](https://i.imgur.com/CTQfIdv.png)

## Source code checklist

- [x] Quality of source code reviews - Too many linting errors, low maintainability
- [x] correct use of design patterns - Only 1 design pattern used: MVC
- [x] respect to code conventions - ok
- [ ] design quality as measured by the number of classes/packages, module size, coupling, cohesion - None
- [x] quality of source code documentation - ok
- [x] refactoring activity documented in commit messages - ok
- [x] quality/detail of commit messages - some commit messages are still too general
- [x] use of feature branches - ok
- [x] atomic commits - ok
- [x] linking of commits to bug reports/features - ok

# Marks

| Content | Max | Earned |
|-|-|-|
| Sprint 4 deliverables:<br>New Deliverables:<br>1. Quality reports (code quality measurement trends, quality management report)<br>2. Release Plan (Sprint #4 planning)<br>3. UI modeling of Sprint #4 user stories<br>Updated deliverables: SAD, USB, Testing plan and Test Summary Report, defects tracking report, RMP | 20 | 17 |
| - Updated/Changed User Stories + Risks | 1 | 1 |
| - Updated Software Architecture: Class diagram | 1 | 1 |
| - Release Plan for Sprint #5 | 1 | 1 |
| - Testing Report: unit tests for the implemented code | 1 | 1 |
| - Updates on the UI Prototypes based on project owner feedback + New UI prototypes | 2 | 2 |
| - Software Implementation of planned user stories + Bug reports/fixing:<br>  + Quality of source code reviews<br>  + correct use of design patterns<br>  + respect to code conventions<br>  + design quality as measured by the number of classes/packages, module size, coupling, cohesion<br>  + quality of source code documentation<br>  + refactoring activity documented in commit messages<br>  + quality/detail of commit messages<br>  + use of feature branches<br>  + atomic commits<br>  + linking of commits to bug reports/features | 10 | 7 |
| - Presentation/Demo to the Product Owner | 4 | 4 |