***

**Present members:**
* All members were present during this meeting  
* Van Tuan Tran  

***

**Meeting start time:**
* 4:00 pm EST  

**Meeting duration:**  
* 30 minutes

***

**Topics discussed:**
* TA will ask prof to verify which prototypes were needed for Sprint 1  
* Will be informed which prototypes are needed for Sprint 2  
* Most points were lost for naming and identifying prototypes  
* Elaboration on definition of Viewpoints  
* Should use 4+1 architecture  
* Every stakeholder will have a viewpoint  
* can merge viewpoints/views into one section  
* Showed that we had a database schema, which was presented during demo  
* Release plan needed for next sprint only  
* Each requirement should be organized into user stories  
* went into detail about the email user story  

***
**Next meeting:**  
* General Meeting: February 15, 2021, at 4:30pm EST  

***
