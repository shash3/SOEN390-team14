# 1. What you did well (in addition to the last sprint)

* Improvements in SAD, well explained the terms and concept used. Good introduction
* Good UI prototype
* Good presentation


# 2. What you need to improve

## 2.1. General

* Meeting minutes should be in an ordered list
* **_Table of contents doesn’t have bookmarks. Cannot quickly navigate between parts (Risk management plan, SAD, UI Prototype)_**

Example:
![toc](https://i.imgur.com/FQChD11.png)

## 2.2. Features, requirements and User stories

* Should present the hierarchy in a better way (e.g. a table?)

## 2.3. Release plan

* If you're using an online service for the release plan, you should include the link to that page.

## 2.4. Software Architecture Description

* Table of contents has a weird format (incorrect indentation)
* **_Misunderstand MVC design pattern. The database is not the model (unless you implement the business logic in the database, usually through `Stored Procedure`)_**
* Blurry images
* **_Still using wrong notations for `Use case` diagrams_**
* Figure 11 presented differently what is described in 1.3.1 Architecture Evaluations
* The class diagram should be in the Development View
* Where are the class diagrams of the backend?
* The deployment view seems not logically correct (Need more explanation)

## 2.5. Risk management

* If the risk tracking is in a table format, you should submit it as an `Excel` file (`*.xlsx`) or `OpenDocument Spreadsheet` file (`*.ods`)

## 2.6. UI Prototypes

* **_Missing some prototypes for the selected features of sprint 3 in the release plan_**

## 2.7. Testing plan

* Not mentioned how many percent of the code should be covered

## 2.8. Defect tracking report

* It is an empty template. For this, I believe an excel file should be adequate. However, the columns should be detailed. At least Summary, Assignee, Reporter, Issue Type, Description, Priority should be included.

## 2.9. Source code

* **_Build is failling_**

![build failed](https://i.imgur.com/0sgHjV5.png)

* **_2 docker command to run the app. Should be only 1_**
* Error running the app
![running app](https://i.imgur.com/Kgc0mE3.png)
* Cannot log in after the client run. (Proxy error: Could not proxy request /api/auth/login from localhost to http://localhost:5000 (ECONNREFUSED).)
* Have code convention, but doesn't have a mechanism to check or enforce the convention.
* **_Seems like all the files in each folder except `models` are named `auth.js`_**
* **_Code is not formated_**
* **_Because the source code is JavaScript, ESLint should be used_**

![eslint result](https://i.imgur.com/2wH7CYF.png)

## 2.10. Source code checklist

- [ ] Quality of source code reviews - No code quality implementation
- [x] correct use of design patterns - Only 1 design pattern used: MVC
- [ ] respect to code conventions - Have coding convention, but no mechanism to enforce the convention on the source code
- [ ] design quality as measured by number of classes/packages, module size, coupling, cohesion - None
- [ ] quality of source code documentation - Poor SAD and/or README, wiki
- [ ] refactoring activity documented in commit messages - Technology stack changed, but no documentation and not mentioned in commit message
- [x] quality/detail of commit messages - some commit messages are still too general
- [x] use of feature branches - ok
- [x] atomic commits - ok
- [ ] linking of commits to bug reports/features - None

# 3. Marks

| Content | Max marks | Earned |
|-|-|-|
| Sprint 2 deliverables:<br>New Deliverables:<br>1. Defects tracking report<br>2. Release Plan (Sprint #3 planning)<br>3. UI modeling of Sprint #3 user stories<br>Updated deliverables: SAD, USB, RMP, Testing Plan | 20 | 17 |
| - Updated/Changed User Stories + Risks | 2 | 2 |
| - Updated Software Architecture: Class diagram | 2 | 1 |
| - Release Plan for Sprint #3 | 2 | 2 |
| - Testing Report: unit tests for the implemented code | 2 | 2 |
| - Updates on the UI Prototypes based on project owner feedback + New UI prototypes | 3 | 3 |
| - Software Implementation of planned user stories + Bug reports/fixing:<br>  + Quality of source code reviews<br>  + correct use of design patterns<br>  + respect to code conventions<br>  + design quality as measured by number of classes/packages, module size, coupling, cohesion<br>  + quality of source code documentation<br>  + refactoring activity documented in commit messages<br>  + quality/detail of commit messages<br>  + use of feature branches<br>  + atomic commits<br>  + linking of commits to bug reports/features | 5 | 3 |
| - Presentation/Demo to the Product Owner | 4 | 4 |